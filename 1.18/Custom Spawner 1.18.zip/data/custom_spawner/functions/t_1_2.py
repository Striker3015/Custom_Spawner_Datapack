### Cow Not included ###

mobs_1 = ["Blaze","Chicken","Creeper","Evoker","Ghast","Glow Squid","Guardian","Iron Golem","Magma Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Witch","Wither Skeleton","Zombie","Zombified Piglin"]
mobs_2 = ["blaze","chicken","creeper","evoker","ghast","glow_squid","guardian","iron_golem","magma_cube","phantom","pig","pillager","rabbit","sheep","shulker","skeleton","slime","spider","vindicator","witch","wither_skeleton","zombie","zombified_piglin"]
mobs_3 = ["Blaze","Chicken","Creeper","Evoker","Ghast","Glow_Squid","Guardian","Iron_Golem","Magma_Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Witch","Wither_Skeleton","Zombie","Zombified_Piglin"]

k = "249"
f = open("t_1_2.txt", "w+")
for i in range(23):
    data = f.read()
    f.write(data + "### "+mobs_1[i]+" ###\nexecute as @e[type="+mobs_2[i]+",nbt={Tags:[\"Custom_Spawner_"+mobs_3[i]+"\"]}] unless entity @s[scores={custom_spawner=-2147483648..2147483647}] run scoreboard players set @s custom_spawner 1\nexecute as @e[type="+mobs_2[i]+",nbt={Tags:[\"Custom_Spawner_"+mobs_3[i]+"\"]},scores={custom_spawner=0.."+k+"},sort=random,limit=1] at @s run execute as @e[type="+mobs_2[i]+",nbt={Tags:[\"Custom_Spawner_"+mobs_3[i]+"\"]},scores={custom_spawner=0.."+k+"},distance=1..3,sort=nearest,limit=1] at @s run function custom_spawner:custom_spawner/"+mobs_2[i]+"/add\n")
f.close()
