### Cow Not included ###

mobs_1 = ["Blaze","Chicken","Creeper","Evoker","Ghast","Glow Squid","Guardian","Iron Golem","Magma Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Witch","Wither Skeleton","Zombie","Zombified Piglin"]
mobs_2 = ["blaze","chicken","creeper","evoker","ghast","glow_squid","guardian","iron_golem","magma_cube","phantom","pig","pillager","rabbit","sheep","shulker","skeleton","slime","spider","vindicator","witch","wither_skeleton","zombie","zombified_piglin"]
mobs_3 = ["Blaze","Chicken","Creeper","Evoker","Ghast","Glow_Squid","Guardian","Iron_Golem","Magma_Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Witch","Wither_Skeleton","Zombie","Zombified_Piglin"]

f = open("t_7.txt", "w+")
for j in range(23):
    data = f.read()
    f.write(data + "# "+mobs_1[j]+" #\nexecute as @e[type=bat ,distance=0..2 ,nbt={Tags:[\"Custom_Spawner_Build_"+mobs_3[j]+"_Spawner\"]}] at @s run function custom_spawner:custom_spawner_build/check\nexecute as @e[type=bat ,distance=0..2 ,nbt={Tags:[\"Custom_Spawner_Build_"+mobs_3[j]+"_Spawner\"]}] at @s run function custom_spawner:custom_spawner_build/build/build_"+mobs_2[j]+"_spawner\n")
f.close()
