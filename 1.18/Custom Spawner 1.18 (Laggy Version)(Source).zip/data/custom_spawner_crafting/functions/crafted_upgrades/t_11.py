
mobs_1 = ["Cow","Blaze","Chicken","Creeper","Evoker","Ghast","Glow Squid","Guardian","Magma Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Witch","Wither Skeleton","Zombie","Zombified Piglin"]
mobs_2 = ["cow","blaze","chicken","creeper","evoker","ghast","glow_squid","guardian","magma_cube","phantom","pig","pillager","rabbit","sheep","shulker","skeleton","slime","spider","vindicator","witch","wither_skeleton","zombie","zombified_piglin"]
mobs_3 = ["Cow","Blaze","Chicken","Creeper","Evoker","Ghast","Glow_Squid","Guardian","Magma_Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Witch","Wither_Skeleton","Zombie","Zombified_Piglin"]

k = "5"
f = open("t_11.txt", "w+")
for j in range(23):
    data = f.read()
    f.write(data + "recipe take @s custom_spawner_crafting:upgrades/upgrade_"+k+"/custom_spawner_upgrade_"+k+"_"+mobs_2[j]+"\n")
data = f.read()
f.write(data + "\n")
for j in range(23):
    data = f.read()
    f.write(data + "advancement revoke @s only custom_spawner_crafting:upgrades/upgrade_"+k+"/craft_custom_spawner_upgrade_"+k+"_"+mobs_2[j]+"_adv\n")
f.close()
