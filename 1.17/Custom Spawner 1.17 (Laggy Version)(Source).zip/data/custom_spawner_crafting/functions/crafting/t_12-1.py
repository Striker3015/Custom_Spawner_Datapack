### Witch and Cow Not included ###

mobs_1 = ["Blaze","Chicken","Creeper","Evoker","Ghast","Glow Squid","Guardian","Magma Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Wither Skeleton","Zombie","Zombified Piglin"]
mobs_2 = ["blaze","chicken","creeper","evoker","ghast","glow_squid","guardian","magma_cube","phantom","pig","pillager","rabbit","sheep","shulker","skeleton","slime","spider","vindicator","wither_skeleton","zombie","zombified_piglin"]
mobs_3 = ["Blaze","Chicken","Creeper","Evoker","Ghast","Glow_Squid","Guardian","Magma_Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Wither_Skeleton","Zombie","Zombified_Piglin"]
mobs_4 = ["blaze_rod","chicken","gunpowder","totem_of_undying","ghast_tear","glow_ink_sac","prismarine_crystals","magma_cream","phantom_membrane","porkchop","crossbow","rabbit","mutton","shulker_shell","bone","slime_ball","spider_eye","emerald_block","wither_skeleton_skull","rotten_flesh","gold_ingot"]


for j in range(21):
    for i in range(4):
        if i == 0: k = "20"
        if i == 1: k = "40"
        if i == 2: k = "60"
        if i == 3: k = "80"
        fileName = mobs_2[j]+"\craft_spawn_egg_"+str(i+1)+".mcfunction"
        f = open(fileName, "w+")
        f.write("\nsummon item ~ ~ ~ {Item:{Count:1b ,id:\"minecraft:"+mobs_4[j]+"\" ,tag:{craft_spawn_egg:"+str(i+1)+"b ,display:{Name:'{\"text\": \""+mobs_1[j]+" Spawn Egg "+k+"%\"}'}}}}\n\nparticle explosion ~ ~ ~ ~ ~ ~ 2 2\nplaysound item.shield.block ambient @a[distance=..3] ~ ~ ~\n\nkill @s\n")
        f.close()
