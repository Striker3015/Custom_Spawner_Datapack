### Cow Not included ###

mobs_1 = ["Blaze","Chicken","Creeper","Evoker","Ghast","Glow Squid","Guardian","Magma Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Witch","Wither Skeleton","Zombie","Zombified Piglin"]
mobs_2 = ["blaze","chicken","creeper","evoker","ghast","glow_squid","guardian","magma_cube","phantom","pig","pillager","rabbit","sheep","shulker","skeleton","slime","spider","vindicator","witch","wither_skeleton","zombie","zombified_piglin"]
mobs_3 = ["Blaze","Chicken","Creeper","Evoker","Ghast","Glow_Squid","Guardian","Magma_Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Witch","Wither_Skeleton","Zombie","Zombified_Piglin"]

for j in range(22):
    fileName = "custom_spawner_upgrade_1_"+mobs_2[j]+".json"
    f = open(fileName, "w+")
    for i in range(1):
        data = f.read()
        f.write(data + "{\n    \"type\": \"minecraft:crafting_shaped\",\n    \"pattern\": [\n        \"222\",\n        \"212\",\n        \"222\"\n    ],\n    \"key\": {\n        \"1\": {\n            \"item\": \"minecraft:"+mobs_2[j]+"_spawn_egg\"\n        },\n        \"2\": {\n            \"item\": \"minecraft:iron_block\"\n        }\n    },\n    \"result\": {\n        \"item\": \"minecraft:knowledge_book\",\n        \"count\": 2\n    }\n}")
    f.close()
