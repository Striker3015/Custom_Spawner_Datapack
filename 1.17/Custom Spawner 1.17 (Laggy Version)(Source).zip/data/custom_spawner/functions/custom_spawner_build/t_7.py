
mobs_1 = ["Blaze","Chicken","Creeper","Ghast","Magma Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither Skeleton","Zombie"]
mobs_2 = ["blaze","chicken","creeper","ghast","magma_cube","phantom","pig","rabbit","sheep","shulker","skeleton","slime","spider","witch","wither_skeleton","zombie"]
mobs_3 = ["Blaze","Chicken","Creeper","Ghast","Magma_Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither_Skeleton","Zombie"]

f = open("t_7.txt", "w+")
for j in range(16):
    data = f.read()
    f.write(data + "# "+mobs_1[j]+" #\nexecute as @e[type=bat ,distance=0..2 ,nbt={Tags:[\"Custom_Spawner_Build_"+mobs_3[j]+"_Spawner\"]}] at @s run function custom_spawner:custom_spawner_build/check\nexecute as @e[type=bat ,distance=0..2 ,nbt={Tags:[\"Custom_Spawner_Build_"+mobs_3[j]+"_Spawner\"]}] at @s run function custom_spawner:custom_spawner_build/build/build_"+mobs_2[j]+"_spawner\n")
f.close()
