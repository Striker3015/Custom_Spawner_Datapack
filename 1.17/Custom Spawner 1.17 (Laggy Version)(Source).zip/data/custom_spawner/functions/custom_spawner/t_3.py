### Cow Not included ###

mobs_1 = ["Blaze","Chicken","Creeper","Evoker","Ghast","Glow Squid","Guardian","Magma Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Witch","Wither Skeleton","Zombie","Zombified Piglin"]
mobs_2 = ["blaze","chicken","creeper","evoker","ghast","glow_squid","guardian","magma_cube","phantom","pig","pillager","rabbit","sheep","shulker","skeleton","slime","spider","vindicator","witch","wither_skeleton","zombie","zombified_piglin"]
mobs_3 = ["Blaze","Chicken","Creeper","Evoker","Ghast","Glow_Squid","Guardian","Magma_Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Witch","Wither_Skeleton","Zombie","Zombified_Piglin"]

k = "499"
for j in range(22):
    fileName = mobs_2[j] + "/add.mcfunction"
    f = open(fileName, "w+")
    for i in range(1):
        data = f.read()
        f.write(data + "\nscoreboard players operation @s custom_spawner += @e[type="+mobs_2[j]+",nbt={Tags:[\"Custom_Spawner_"+mobs_3[j]+"\"]},scores={custom_spawner=0.."+k+"},distance=1..3,sort=nearest,limit=1] custom_spawner\n\ntag @e[type="+mobs_2[j]+",nbt={Tags:[\"Custom_Spawner_"+mobs_3[j]+"\"]},scores={custom_spawner=0.."+k+"},distance=1..3,sort=nearest,limit=1] add Kill\n\nfunction custom_spawner:custom_spawner/"+mobs_2[j]+"/name\n")
    f.close()
