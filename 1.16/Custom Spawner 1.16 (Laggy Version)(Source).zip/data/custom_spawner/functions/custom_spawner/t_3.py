
mobs_1 = ["Blaze","Chicken","Creeper","Ghast","Magma Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither Skeleton","Zombie"]
mobs_2 = ["blaze","chicken","creeper","ghast","magma_cube","phantom","pig","rabbit","sheep","shulker","skeleton","slime","spider","witch","wither_skeleton","zombie"]
mobs_3 = ["Blaze","Chicken","Creeper","Ghast","Magma_Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither_Skeleton","Zombie"]

for j in range(16):
    fileName = mobs_2[j] + "/add.mcfunction"
    f = open(fileName, "w+")
    for i in range(1):
        data = f.read()
        f.write(data + "\nscoreboard players operation @s custom_spawner += @e[type="+mobs_2[j]+",nbt={Tags:[\"Custom_Spawner_"+mobs_3[j]+"\"]},scores={custom_spawner=0..499},distance=1..3,sort=nearest,limit=1] custom_spawner\n\ntag @e[type="+mobs_2[j]+",nbt={Tags:[\"Custom_Spawner_"+mobs_3[j]+"\"]},scores={custom_spawner=0..499},distance=1..3,sort=nearest,limit=1] add Kill\n\nfunction custom_spawner:custom_spawner/"+mobs_2[j]+"/name\n")
    f.close()
