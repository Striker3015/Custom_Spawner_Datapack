
mobs_1 = ["Blaze","Chicken","Creeper","Ghast","Magma Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither Skeleton","Zombie"]
mobs_2 = ["blaze","chicken","creeper","ghast","magma_cube","phantom","pig","rabbit","sheep","shulker","skeleton","slime","spider","witch","wither_skeleton","zombie"]
mobs_3 = ["Blaze","Chicken","Creeper","Ghast","Magma_Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither_Skeleton","Zombie"]

for j in range(16):
    fileName = mobs_2[j] + "/name.mcfunction"
    f = open(fileName, "w+")
    for i in range(999):
        data = f.read()
        f.write(data + "execute as @s[scores={custom_spawner="+str(i+2)+"}] run data modify entity @s CustomName set value '{\"text\": \""+str(i+2)+"* "+mobs_1[j]+"\"}'\n")
    f.close()
