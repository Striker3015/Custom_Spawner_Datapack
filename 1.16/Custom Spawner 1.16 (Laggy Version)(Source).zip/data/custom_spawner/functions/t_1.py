
mobs_1 = ["Blaze","Chicken","Creeper","Ghast","Magma Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither Skeleton","Zombie"]
mobs_2 = ["blaze","chicken","creeper","ghast","magma_cube","phantom","pig","rabbit","sheep","shulker","skeleton","slime","spider","witch","wither_skeleton","zombie"]
mobs_3 = ["Blaze","Chicken","Creeper","Ghast","Magma_Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither_Skeleton","Zombie"]

f = open("t_1.txt", "w+")
for i in range(16):
    data = f.read()
    f.write(data + "execute as @e[nbt={Tags:[\"Custom_Spawner_"+mobs_3[i]+"\"]}] at @s run function custom_spawner:custom_spawner/"+mobs_2[i]+"/name\n")
f.close()
