
mobs_1 = ["Blaze","Chicken","Creeper","Ghast","Magma Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither Skeleton","Zombie"]
mobs_2 = ["blaze","chicken","creeper","ghast","magma_cube","phantom","pig","rabbit","sheep","shulker","skeleton","slime","spider","witch","wither_skeleton","zombie"]
mobs_3 = ["Blaze","Chicken","Creeper","Ghast","Magma_Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither_Skeleton","Zombie"]

for j in range(16):
    fileName = "craft_custom_spawner_upgrade_2_"+mobs_2[j]+"_adv.json"
    f = open(fileName, "w+")
    for i in range(1):
        data = f.read()
        f.write(data + "{\n    \"criteria\": {\n        \"pistolUnlocked\": {\n            \"trigger\": \"minecraft:recipe_unlocked\",\n            \"conditions\": {\n                \"recipe\": \"custom_spawner_crafting:upgrades/upgrade_2/custom_spawner_upgrade_2_"+mobs_2[j]+"\"\n            }\n        }\n    },\n    \"rewards\": {\n        \"function\": \"custom_spawner_crafting:crafted_upgrades/crafted_custom_spawner_upgrade_2\"\n    }\n}")
    f.close()
