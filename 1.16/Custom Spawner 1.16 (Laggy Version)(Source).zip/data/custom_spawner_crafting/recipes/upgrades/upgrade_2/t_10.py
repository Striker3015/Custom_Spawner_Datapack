
mobs_1 = ["Blaze","Chicken","Creeper","Ghast","Magma Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither Skeleton","Zombie"]
mobs_2 = ["blaze","chicken","creeper","ghast","magma_cube","phantom","pig","rabbit","sheep","shulker","skeleton","slime","spider","witch","wither_skeleton","zombie"]
mobs_3 = ["Blaze","Chicken","Creeper","Ghast","Magma_Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither_Skeleton","Zombie"]

for j in range(16):
    fileName = "custom_spawner_upgrade_2_"+mobs_2[j]+".json"
    f = open(fileName, "w+")
    for i in range(1):
        data = f.read()
        f.write(data + "{\n    \"type\": \"minecraft:crafting_shaped\",\n    \"pattern\": [\n        \"222\",\n        \"212\",\n        \"222\"\n    ],\n    \"key\": {\n        \"1\": {\n            \"item\": \"minecraft:"+mobs_2[j]+"_spawn_egg\"\n        },\n        \"2\": {\n            \"item\": \"minecraft:gold_block\"\n        }\n    },\n    \"result\": {\n        \"item\": \"minecraft:knowledge_book\",\n        \"count\": 2\n    }\n}")
    f.close()
