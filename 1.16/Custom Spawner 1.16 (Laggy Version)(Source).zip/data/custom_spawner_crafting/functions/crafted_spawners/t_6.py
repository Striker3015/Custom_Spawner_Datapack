### Cow Not included ###

mobs_1 = ["Blaze","Chicken","Creeper","Evoker","Ghast","Glow Squid","Guardian","Magma Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Witch","Wither Skeleton","Zombie","Zombified Piglin"]
mobs_2 = ["blaze","chicken","creeper","evoker","ghast","glow_squid","guardian","magma_cube","phantom","pig","pillager","rabbit","sheep","shulker","skeleton","slime","spider","vindicator","witch","wither_skeleton","zombie","zombified_piglin"]
mobs_3 = ["Blaze","Chicken","Creeper","Evoker","Ghast","Glow_Squid","Guardian","Magma_Cube","Phantom","Pig","Pillager","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Vindicator","Witch","Wither_Skeleton","Zombie","Zombified_Piglin"]


for j in range(22):
    fileName = "crafted_custom_spawner_"+mobs_2[j]+".mcfunction"
    f = open(fileName, "w+")
    for i in range(1):
        data = f.read()
        f.write(data + "\nrecipe take @s custom_spawner_crafting:spawners/custom_spawner_"+mobs_2[j]+"\n\nadvancement revoke @s only custom_spawner_crafting:craft_custom_spawner_"+mobs_2[j]+"_adv\n\ngive @s bat_spawn_egg{display:{Name:'{ \"text\": \""+mobs_1[j]+" Spawner\"}' ,Lore:['{\"text\": \"Custom Spawner Datapack\"}']},EntityTag:{Tags:[\"Custom_Spawner_Build_"+mobs_3[j]+"_Spawner\"] ,NoAI:1b ,Silent:1b ,NoGravity:1b} ,CustomModelData:825560} 1\n\nclear @s minecraft:knowledge_book\n")
    f.close()
