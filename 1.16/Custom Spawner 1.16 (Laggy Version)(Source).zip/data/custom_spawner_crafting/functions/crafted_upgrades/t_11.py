
mobs_1 = ["Blaze","Chicken","Creeper","Ghast","Magma Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither Skeleton","Zombie"]
mobs_2 = ["blaze","chicken","creeper","ghast","magma_cube","phantom","pig","rabbit","sheep","shulker","skeleton","slime","spider","witch","wither_skeleton","zombie"]
mobs_3 = ["Blaze","Chicken","Creeper","Ghast","Magma_Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Witch","Wither_Skeleton","Zombie"]

f = open("t_11.txt", "w+")
for j in range(16):
    data = f.read()
    f.write(data + "advancement revoke @s only custom_spawner_crafting:upgrades/upgrade_1/craft_custom_spawner_upgrade_1_"+mobs_2[j]+"_adv\n")
f.close()
