### Witch and Cow Not included ###

mobs_1 = ["Blaze","Chicken","Creeper","Ghast","Magma Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Wither Skeleton","Zombie"]
mobs_2 = ["blaze","chicken","creeper","ghast","magma_cube","phantom","pig","rabbit","sheep","shulker","skeleton","slime","spider","wither_skeleton","zombie"]
mobs_3 = ["Blaze","Chicken","Creeper","Ghast","Magma_Cube","Phantom","Pig","Rabbit","Sheep","Shulker","Skeleton","Slime","Spider","Wither_Skeleton","Zombie"]
mobs_4 = ["blaze_rod","chicken","gunpowder","ghast_tear","magma_cream","phantom_membrane","porkchop","rabbit","mutton","shulker_shell","bone","slime_ball","spider_eye","wither_skeleton_skull","rotten_flesh"]


for j in range(15):
    fileName = mobs_2[j]+"\craft_spawn_egg_5.mcfunction"
    f = open(fileName, "w+")
    f.write("\nsummon item ~ ~ ~ {Item:{Count:1b ,id:\"minecraft:"+mobs_2[j]+"_spawn_egg\"}}\n\nparticle explosion ~ ~ ~ ~ ~ ~ 2 2\nplaysound item.shield.block ambient @a[distance=..3] ~ ~ ~\n\nkill @s\n")
    f.close()
